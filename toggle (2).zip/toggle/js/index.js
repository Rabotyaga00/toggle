const player = document.getElementById('player');
const field = document.getElementById('field');
let position = { top: 100, left: 100 };
let number =1;

function moveBox(event) {
    switch(event.key) {
        case 'ArrowLeft':
            position.left -= 10;
            break;
        case 'ArrowRight':
            position.left += 10;
            break;
    }
    if (position.left >= 0 && position.left <= 300) {
        player.style.left = position.left + 'px';
        number = Math.floor((position.left / 300) * 3) + 1; // от 1 до 4
        player.textContent = number;
    }

    // Изменение цвета на основе позиции
    const colorValue = Math.floor((position.left / 300) * 255);
    player.style.backgroundColor = `rgb(${colorValue}, 0, ${255 - colorValue})`;
    field.style.borderColor = `rgb(${colorValue}, 0, ${255 - colorValue})`;
}

document.addEventListener('keydown', moveBox);
